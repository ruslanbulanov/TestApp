from django.shortcuts import render
from Park.models import *
# Create your views here.


def landing_view(requset):
    context = {

    }
    return render(requset, 'landing-page.html', context)


def map_view(requset):

    context = {

    }
    return render(requset, 'map-page.html', context)