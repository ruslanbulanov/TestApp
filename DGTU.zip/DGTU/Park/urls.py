from django.conf.urls import url, include
from django.urls import path
from Park.views import *
from . import views

urlpatterns = {
    path('', views.landing_view),
    # path('map/', views.map_view, name='map')
}