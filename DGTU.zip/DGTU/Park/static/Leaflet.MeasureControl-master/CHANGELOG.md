
1.2.0 / 2018-03-09
==================

  * Put changelog in a dedicated file
  * Lint README file and add languages to code blocks
  * Enforce new ESLint setup
  * Use eslint-config-makina for linting and adapt rules
  * Set leaflet Draw as peerDependency
  * Add npm script for linting
  * Adapt and enforce eslint rules
  * Migrate from minifier to uglifyjs
  * Upgrade normalize.css to latest version
  * Regroup scripts and styles by dependencies
  * Simplify demo by including css and style from current project
  * Remove useless elements in demo html
  * Embed demo scripts in html
  * Use Leaflet Draw from CDN instead of including it in sources
  * Config responsive menu and add github logo

1.1.0 / 2016-09-05
==================

  * Add npm support
  * Add support for AMD and CommonJS loading
  * Set example in docs folder

1.0.0
=====

  * Initial version
